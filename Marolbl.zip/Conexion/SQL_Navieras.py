import pyodbc

_CONN_STR = (
    "DRIVER={ODBC Driver 17 for SQL Server};"
    "SERVER=192.168.0.17;"
    "DATABASE=ProcesoMarol;"
    "UID=sa;"
    "PWD=HP789_ramonG3;"
    "Persist Security Info=True;"
    "Encrypt=yes;"
    "TrustServerCertificate=YES;"
)


def _connect():
    """
    Conecta a SQL Server cuando se necesite (evita conexión al importar).
    """
    return pyodbc.connect(_CONN_STR)

# Verificar si el DO existe y devolver opcionalmente el ETA actual
def CHECK_TABLE(do, return_eta=False):
    query = "SELECT ETA FROM TRK_NAVIERA_LOG WHERE DO = ? ORDER BY ID DESC"
    with _connect() as conexion:
        cursor = conexion.cursor()
        cursor.execute(query, (do,))
        row = cursor.fetchone()
    if row:
        return (True, row[0]) if return_eta else True
    return (False, None) if return_eta else False


def CHECK_TABLE2(do, return_eta=False):
    query = "SELECT * FROM TRK_NAVIERA_LOG WHERE DO = ? ORDER BY ID DESC"
    with _connect() as conexion:
        cursor = conexion.cursor()
        cursor.execute(query, (do,))
        return cursor.fetchall()

# Insertar un nuevo registro
def INSERT_INTO(do, bl, eta, estado, naviera, fecha_actual):
    result = CHECK_TABLE2(do)
    eta_Db = ""
    if result:
        eta_Db = result[0][3]
    else: 
        eta_Db = None

    if eta_Db == eta:
        print('Las Etas Son igaules')
    elif eta_Db == None:
        query = """
        INSERT INTO TRK_NAVIERA_LOG (DO, BL, ETA, ESTADO, NAVIERA, FECHA_CONSULTA)
        VALUES (?, ?, ?, ?, ?, ?)
        """
        with _connect() as conexion:
            cursor = conexion.cursor()
            cursor.execute(query, (do, bl, eta, estado, naviera, fecha_actual))
            conexion.commit()
    elif eta_Db != eta:
        query = """
            UPDATE TRK_NAVIERA_LOG
            SET
            BL = ?,
            ETA = ?,
            ESTADO = ?,
            NAVIERA = ?,
            FECHA_CONSULTA = ?
            WHERE DO = ?
        """
        with _connect() as conexion:
            cursor = conexion.cursor()
            cursor.execute(query, (bl, eta, estado, naviera, fecha_actual, do))
            conexion.commit()

# Obtener la última ETA desde la base de datos para un DO
def GET_ETA_FROM_DB(do):
    query = "SELECT ETA FROM TRK_NAVIERA_LOG WHERE DO = ? ORDER BY ID DESC"
    with _connect() as conexion:
        cursor = conexion.cursor()
        cursor.execute(query, (do,))
        row = cursor.fetchone()
        return row[0] if row else None





import pyodbc
import pandas as pd
from datetime import datetime
import os

def obtener_datos_tracking() -> list[tuple[str, str]]:
    """Consulta SQL y devuelve lista de (DO, Doc_transp)"""
    try:
        conexion = pyodbc.connect(
            "DRIVER={ODBC Driver 17 for SQL Server};"
            "SERVER=192.168.0.17;"
            "DATABASE=ProcesoMarol;"
            "UID=sa;"
            "PWD=HP789_ramonG3;"
            "Persist Security Info=True;"
            "Encrypt=yes;"
            "TrustServerCertificate=YES;"
        )

        query = """
                SELECT
            AD.do,
            AP.Doc_transp
        FROM Abrir_do AS AD
        LEFT JOIN Mariano..Decimpo AS DM ON AD.do = DM.cod
        LEFT JOIN Mariano..AperturaDO AS AP ON AD.do = AP.nro_do
        WHERE
            AD.Do_cerrado = 'N'
            AND ISNULL(DM.manifiesto, '') = ''
            AND AD.fecha >= DATEFROMPARTS(YEAR(GETDATE()),1,1)
            AND AP.Doc_transp IS NOT NULL
            AND AP.Doc_transp <> ''
			AND AD.Anular <> 'S' 
        """

        df = pd.read_sql(query, conexion)
        conexion.close()

        resultados = []
        for _, fila in df.iterrows():
            do = str(fila['do']).strip()
            doc_transp = str(fila['Doc_transp']).strip()
            resultados.append((do, doc_transp))

        print(f"🔍 Trackings obtenidos desde SQL: {len(resultados)}")
        return resultados

    except Exception as e:
        print(f"❌ Error en la conexión SQL: {e}")
        return []

def guardar_en_excel_tracking(datos: list[tuple[str, str]]):
    """Guarda los datos en un archivo Excel en la ruta TRACKING-BL con fecha actual"""
    fecha_actual = datetime.now().strftime("%Y-%m-%d")
    carpeta = os.path.join(os.path.expanduser("~"), "Documents", "TRACKING-BL", fecha_actual, "Log")
    os.makedirs(carpeta, exist_ok=True)
    archivo_excel = os.path.join(carpeta, f"log_sql.xlsx")

    # Crear DataFrame con columnas necesarias
    data = []
    for do, tracking in datos:
        data.append({
            "DO": do,
            "TRACKING": tracking,
            "ESTADO": "PENDIENTE",  # puedes ajustar esto si tienes un valor real
            "FECHA ACTUAL": fecha_actual
        })

    df = pd.DataFrame(data, columns=["DO", "TRACKING", "ESTADO", "FECHA ACTUAL"])
    df.to_excel(archivo_excel, index=False)
    print(f"✅ Archivo guardado en: {archivo_excel}")

# --- Ejecutar todo ---
if __name__ == "__main__":
    datos = obtener_datos_tracking()
    if datos:
        guardar_en_excel_tracking(datos)


def guardar_log_resultado(datos_estado: list[dict]):
    import pandas as pd
    from datetime import datetime
    import os

    fecha_actual = datetime.now().strftime("%Y-%m-%d")
    carpeta = os.path.join(os.path.expanduser("~"), "Documents", "TRACKING-BL","BL_Consultados" )
    os.makedirs(carpeta, exist_ok=True)
    archivo_excel = os.path.join(carpeta, "registro_global_Zim.xlsx")

    df = pd.DataFrame(datos_estado)
    df.to_excel(archivo_excel, index=False)
    print(f"✅ Log de resultados guardado en: {archivo_excel}")


def guardar_log_resultado2(naviera, datos_estado):
    import pandas as pd
    from datetime import datetime
    import os

    fecha_actual = datetime.now().strftime("%Y-%m-%d")
    carpeta = os.path.join(os.path.expanduser("~"), "Documents", "TRACKING-BL", fecha_actual, "Log")
    os.makedirs(carpeta, exist_ok=True)
    archivo_excel = os.path.join(carpeta, f"log_resultado_{naviera}.xlsx")

    df = pd.DataFrame(datos_estado)
    df.to_excel(archivo_excel, index=False)
    print(f"✅ Log de resultados guardado en: {archivo_excel}")