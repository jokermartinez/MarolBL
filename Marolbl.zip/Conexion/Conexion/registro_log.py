# Conexion/registro_log.py
import pyodbc
from datetime import datetime

def obtener_conexion():
    return pyodbc.connect(
        "DRIVER={ODBC Driver 17 for SQL Server};"
        "SERVER=192.168.1.48;"
        "DATABASE=ProcesoMaLog;"
        "UID=sa;"
        "PWD=Marol2025*;"
        "Persist Security Info=True;"
        "Encrypt=yes;"
        "TrustServerCertificate=YES;"
    )

def insertar_log(do, bl, estado, naviera, fecha_consulta=None):
    if fecha_consulta is None:
        fecha_consulta = datetime.now()

    try:
        conexion = obtener_conexion()
        cursor = conexion.cursor()
        query = """
        INSERT INTO TRK_REGISTRO_LOG (DO, BL, ESTADO, NAVIERA, FECHA_CONSULTA)
        VALUES (?, ?, ?, ?, ?)
        """
        cursor.execute(query, (do, bl, estado, naviera, fecha_consulta))
        conexion.commit()
        conexion.close()
        print(f"✅ Insertado en TRK_REGISTRO_LOG: {do}, {bl}, {estado}, {naviera}")
    except Exception as e:
        print(f"❌ Error al insertar en TRK_REGISTRO_LOG: {e}")

def insertar_varios(datos_log, naviera="EVERGREEN"):
    """
    datos_log: lista de listas [DO, BL, ESTADO]
    naviera: nombre de la naviera
    """
    for do, bl, estado, *_ in datos_log:
        insertar_log(do, bl, estado, naviera)
