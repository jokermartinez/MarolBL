import os
import pyodbc
import pandas as pd
from datetime import datetime

# 📂 Carpeta donde se guardará el Excel
carpeta_log = os.path.join(os.path.expanduser("~"), "Documents", "TRACKING-BL", "BL_Consultados")
os.makedirs(carpeta_log, exist_ok=True)
archivo_excel = os.path.join(carpeta_log, "registro_global.xlsx")

def obtener_datos_tracking() -> list[tuple[str, str]]:
    """Consulta SQL y devuelve lista de (DO, Doc_transp)"""
    try:
        conexion = pyodbc.connect(
            "DRIVER={ODBC Driver 17 for SQL Server};"
            "SERVER=192.168.0.17;"
            "DATABASE=ProcesoMarol;"
            "UID=sa;"
            "PWD=HP789_ramonG3;"
            "Persist Security Info=True;"
            "Encrypt=yes;"
            "TrustServerCertificate=YES;"
        )

        query = """
            SELECT
                AD.do,
                AP.Doc_transp
            FROM Abrir_do AS AD
            LEFT JOIN Mariano..Decimpo AS DM ON AD.do = DM.cod
            LEFT JOIN Mariano..AperturaDO AS AP ON AD.do = AP.nro_do
            WHERE
                AD.Do_cerrado = 'N'
                AND ISNULL(DM.manifiesto, '') = ''
                AND AD.fecha >= DATEFROMPARTS(YEAR(GETDATE()),1,1)
                AND AP.Doc_transp IS NOT NULL
                AND AP.Doc_transp <> ''
                AND AD.Anular <> 'S' 
        """

        df = pd.read_sql(query, conexion)
        conexion.close()

        # 🚀 Guardar directamente en Excel
        fecha_hora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        df["Fecha_Exportacion"] = fecha_hora

        df.to_excel(archivo_excel, index=False)

        print(f"✅ Datos exportados a: {archivo_excel}")
        return df.values.tolist()

    except Exception as e:
        print(f"❌ Error en la conexión SQL: {e}")
        return []

# Ejecutar función
if __name__ == "__main__":
    obtener_datos_tracking()
