import os
import asyncio
from datetime import datetime
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError
from openpyxl import Workbook, load_workbook
# from Datos.guardar_log import log_sql
from Datos.Exportar import excel_evergreen, save_container_table
from Conexion.SQL_Navieras import CHECK_TABLE, INSERT_INTO, obtener_datos_tracking
from Datos.mover_pdfs import mover_pdfs
from Datos.Reg_log import  registro_global
#from Conexion.D_real_SQL_Exel import  log_Exc_Sql

fecha = datetime.now().strftime("%Y-%m-%d")
fecha_hora = datetime.now().strftime("%Y%m%d %H%M%S")
fecha_fin = fecha_hora.replace('-', '')


def get_tracking_folder():
    carpeta = os.path.join(os.path.expanduser("~"), "Documents", "TRACKING-BL", fecha)
    os.makedirs(carpeta, exist_ok=True)
    return carpeta

def load_trackings():
    try:
        datos = obtener_datos_tracking()
        #log_Exc_Sql()
        return [
            (do, tr) for do, tr in datos 
            if isinstance(tr, str) and (tr.startswith("EGLV") or tr.startswith("ASS"))
        ]
    except Exception as e:
        print("❌ Error al leer desde SQL:", e)
        return []


# ✅ FUNCION LOG GLOBAL
def actualizar_registro_global(datos_log):
    carpeta_log = os.path.join(os.path.expanduser("~"), "Documents", "TRACKING-BL", "BL_Consultados")
    os.makedirs(carpeta_log, exist_ok=True)
    ruta_registro_global = os.path.join(carpeta_log, "registro_logEverg.xlsx")
    fecha_actual = datetime.now().strftime("%Y-%m-%d")

    if os.path.exists(ruta_registro_global):
        wb = load_workbook(ruta_registro_global)
        ws = wb.active

        registros_existentes = {
            (str(ws.cell(row=i, column=1).value), str(ws.cell(row=i, column=2).value)): i
            for i in range(2, ws.max_row + 1)
        }

        for do, tr, estado, *_ in datos_log:
            clave = (str(do), str(tr))
            if clave in registros_existentes:
                fila = registros_existentes[clave]
                ws.cell(row=fila, column=3, value=estado)
                ws.cell(row=fila, column=4, value=fecha_actual)
            else:
                ws.append([do, tr, estado, fecha_actual])
    else:
        wb = Workbook()
        ws = wb.active
        ws.title = "Registro_Global"
        ws.append(["DO", "TRACKING", "ESTADO", "FECHA"])
        for do, tr, estado, *_ in datos_log:
            ws.append([do, tr, estado, fecha_actual])

    wb.save(ruta_registro_global)
    print(f"📄 Registro global actualizado en {ruta_registro_global}")


async def save_pdf(page, do, tracking, carpeta):
    carpetapdf = os.path.join(os.path.expanduser("~"), "Documents", "TRACKING-BL", "PDF")
    os.makedirs(carpetapdf, exist_ok=True)
    nombre_pdf = f"{do}-TRK_{tracking}_{fecha_fin}.pdf"
    ruta_pdf = os.path.join(carpetapdf, nombre_pdf)
    await page.pdf(path=ruta_pdf, format="A4", print_background=True)
    print(f"📄 PDF guardado: {tracking}")


def save_container_table_unificada(carpeta, rows, do, tracking):
    ruta_excel = os.path.join(carpeta, "TRACKING-BL.xlsx")
    wb = load_workbook(ruta_excel) if os.path.exists(ruta_excel) else Workbook()
    if "EVERGREEN_CTN" in wb.sheetnames:
        ws = wb["EVERGREEN_CTN"]
    else:
        ws = wb.create_sheet("EVERGREEN_CTN")
        ws.append(["DO", "Tracking", "Contenedor", "Tamaño", "Tipo", "Estado", "Peso", "Fecha", "Ubicación", "Evento", "Destino"])
    for fila in rows:
        ws.append([do, tracking] + fila)
    wb.save(ruta_excel)


def guardar_fecha_ETA(carpeta, do, tracking, fecha_eta, comentario=""):
    ruta_ETA = os.path.join(carpeta, "ETA.xlsx")
    wb = load_workbook(ruta_ETA) if os.path.exists(ruta_ETA) else Workbook()
    if "Evergreen" in wb.sheetnames:
        ws = wb["Evergreen"]
    else:
        ws = wb.create_sheet("Evergreen")
        ws.append(["DO", "Tracking", "ETA", "Estado"])
    ws.append([do, tracking, fecha_eta, comentario])
    wb.save(ruta_ETA)


async def ejecutar_evergreen():
    carpeta = get_tracking_folder()
    log_folder = os.path.join(carpeta, "Log")
    os.makedirs(log_folder, exist_ok=True)
    trackings = load_trackings()

    encontrados = []
    no_encontrados = []

    if not trackings:
        print("⚠️ No hay datos para procesar.")
        return

    async with async_playwright() as p:
        browser = await p.chromium.launch(channel="msedge", headless=False)
        page = await browser.new_page()
        await page.goto("https://ct.shipmentlink.com/servlet/TDB1_CargoTracking.do")
        await asyncio.sleep(0.5)

        try:
            await page.locator("#shipmentlink_lang_layer > div:nth-child(3) > button:nth-child(1)").click(timeout=15000)
        except PlaywrightTimeoutError:
            print("⚠️ Botón de idioma no encontrado")

        try:
            await page.locator("#btn_cookie_accept_all").click(timeout=5000)
        except PlaywrightTimeoutError:
            pass
        
        total = len(trackings)
        for index, (do, tracking_original) in enumerate(trackings, 1):
            # 👇 SOLO quitar letras si el tracking empieza con "EGLV"
            if tracking_original.startswith("EGLV"):
                tracking_consulta = ''.join(filter(str.isdigit, tracking_original))
            else:
                tracking_consulta = tracking_original

            print(f"\n🔎 Procesando: {index}/{total} → {tracking_original}")

            try:
                await page.wait_for_selector('#NO', timeout=5000)
                await page.fill('#NO', tracking_consulta)
                await asyncio.sleep(0.5)
                await page.keyboard.press("Enter")
                await asyncio.sleep(2)

                # (continúa tu lógica normal aquí...)


        # total = len(trackings)
        # for index, (do, tracking_original) in enumerate(trackings, 1):
        #     tracking_consulta = ''.join(filter(str.isdigit, tracking_original))
        #     print(f"\n🔎 Procesando: {index}/{total} → {tracking_original}")

        #     try:
        #         await page.fill('#NO', tracking_consulta)
        #         await asyncio.sleep(0.5)
        #         await page.keyboard.press("Enter")
        #         await asyncio.sleep(2)
                
                try:
                    await page.locator("#shipmentlink_lang_layer > div:nth-child(3) > button:nth-child(1)").click(timeout=5000)
                except PlaywrightTimeoutError:
                    pass

                mensaje = await page.query_selector('td.ec-p-2.ec-fs-16.align-items-center')
                if mensaje:
                    contenido = await mensaje.inner_text()
                    if "NO HAY CONTENIDO" in contenido.upper():
                        no_encontrados.append([do, tracking_original, "No Encontrado"])
                        continue

                all_tables = page.locator('table.ec-table.ec-table-sm')
                if await all_tables.count() >= 3:
                    third_table = all_tables.nth(2)
                    last_row = third_table.locator('tr').last
                    td1 = await last_row.locator('td:nth-child(1)').inner_text()
                    td8 = await last_row.locator('td:nth-child(8)').inner_text()
                    td9 = await last_row.locator('td:nth-child(9)').inner_text()

                    fecha_estimada_elem = await page.query_selector("body > div.ec-content > center > table:nth-child(3) > tbody > tr > td > table:nth-child(3) font")
                    fecha_estimada = await fecha_estimada_elem.inner_text() if fecha_estimada_elem else "No Hay Fecha"

                    try:
                        eta_dt = datetime.strptime(fecha_estimada.strip(), "%b-%d-%Y")
                        eta_limpia = eta_dt.strftime("%Y/%m/%d")
                    except ValueError:
                        eta_limpia = fecha_estimada.strip()

                    existe_db, eta_actual = CHECK_TABLE(do, return_eta=True)

                    if not existe_db:
                        estado_eta = "Nuevo"
                        INSERT_INTO(do, tracking_original, eta_limpia, estado_eta, "EVERGREEN", datetime.now().strftime("%Y-%m-%d_%H:%M:%S"))
                    elif eta_limpia != eta_actual:
                        estado_eta = "Actualizado"
                        INSERT_INTO(do, tracking_original, eta_limpia, estado_eta, "EVERGREEN", datetime.now().strftime("%Y-%m-%d_%H:%M:%S"))
                    else:
                        encontrados.append([do, tracking_original, "Sin Cambio"])
                        continue

                    excel_evergreen(carpeta, tracking_original, [[td1.strip(), td8.strip(), td9.strip(), eta_limpia]])
                    guardar_fecha_ETA(carpeta, do, tracking_original, eta_limpia, estado_eta)
                    encontrados.append([do, tracking_original, estado_eta])

                    if estado_eta in ["Nuevo", "Actualizado"]:
                        await save_pdf(page, do, tracking_original, carpeta)

                else:
                    no_encontrados.append([do, tracking_original, "No encontrado"])

                await page.goto("https://ct.shipmentlink.com/servlet/TDB1_CargoTracking.do")
                await asyncio.sleep(1)

            except Exception as e:
                no_encontrados.append([do, tracking_original, "Error"])

        await browser.close()

    datos_log = encontrados + no_encontrados
    #ruta_log = os.path.join(log_folder, "log_tracking.xlsx")
    registro_global(datos_log)
    from Conexion.registro_log import insertar_varios
    insertar_varios(datos_log, naviera="EVERGREEN")


    # ✅ REGISTRO GLOBAL
    #actualizar_registro_global(datos_log)

    print(f"\n✅ EVERGREEN finalizado. Total: {len(trackings)} | ✔️ Encontrados: {len(encontrados)} | ❌ No encontrados: {len(no_encontrados)}")


if __name__ == "__main__":
    asyncio.run(ejecutar_evergreen())
