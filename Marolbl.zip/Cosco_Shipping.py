import os
import time
from datetime import datetime
from openpyxl import Workbook, load_workbook
from playwright.async_api import async_playwright
from bs4 import BeautifulSoup
import pandas as pd

from Datos.guardar_log import log_sql
from Conexion.SQL_Navieras import CHECK_TABLE, INSERT_INTO, obtener_datos_tracking
from Datos.Filtrar import Filtro_Cosco
from Datos.mover_pdfs import mover_pdfs


HEADERS = ["DO", "Tracking", "MOTONAVE", "Fecha llegada", "Servicio / Viaje", "POL", "Fecha de salida", "PUERTO"]

def carpeta_dia():
    base = os.path.join(os.path.expanduser("~"), "Documents", "TRACKING-BL", datetime.now().strftime("%Y-%m-%d"))
    os.makedirs(base, exist_ok=True)
    return base

def filtrar_codigos(datos) -> list[tuple[str, str]]:
    resultado = []
    for do, doc in datos:
        doc = str(doc).strip().upper()
        if (doc.startswith("COSU") and doc[4:].isdigit()) or doc.startswith(("TII", "FF", "OO", "TL", "TR", "TX", "TG")):
            resultado.append((do.strip(), doc))
    return resultado

def guardar_excel(datos, hoja, encabezado, ruta, estado_eta, eta_fecha):
    for dato in datos:
        Select = CHECK_TABLE(dato[0])
        if not Select and dato[3] != "":
            Fecha = Filtro_Cosco(eta_fecha)
            INSERT_INTO(dato[0], dato[1], Fecha, estado_eta, "COSCO", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

    if os.path.exists(ruta):
        wb = load_workbook(ruta)
    else:
        wb = Workbook()
    if "Sheet" in wb.sheetnames and wb["Sheet"].max_row == 1 and wb["Sheet"].cell(1, 1).value is None:
        wb.remove(wb["Sheet"])
    if hoja not in wb.sheetnames:
        ws = wb.create_sheet(hoja)
        ws.append(encabezado)
    else:
        ws = wb[hoja]
        if ws.max_row == 1 and ws.cell(1, 1).value is None:
            ws.append(encabezado)
    for fila in datos:
        ws.append(fila)
    wb.save(ruta)

def cargar_registros_eta(ruta_eta):
    existentes = {}
    if os.path.exists(ruta_eta):
        wb = load_workbook(ruta_eta)
        if "Cosco_ETA" in wb.sheetnames:
            ws = wb["Cosco_ETA"]
            for row in ws.iter_rows(min_row=2, values_only=True):
                do, _, eta = row[:3]
                existentes[str(do)] = str(eta)
    return existentes

def guardar_fecha_cosco_eta(ruta_eta, do, tracking, fecha_eta, estado):
    if os.path.exists(ruta_eta):
        wb = load_workbook(ruta_eta)
    else:
        wb = Workbook()
        wb.remove(wb.active)
    if "Cosco_ETA" not in wb.sheetnames:
        ws = wb.create_sheet("Cosco_ETA")
        ws.append(["DO", "Tracking", "ETA", "Estado"])
    else:
        ws = wb["Cosco_ETA"]
    ws.append([do, tracking, fecha_eta, estado])
    wb.save(ruta_eta)

def guardar_expected_actual(texto_original, ruta_destino):
    expected = ""
    actual = ""
    if "Expected：" in texto_original and "Actual：" in texto_original:
        partes = texto_original.split("Actual：")
        expected = partes[0].strip()
        actual = "Actual：" + partes[1].strip()

    if not os.path.exists(ruta_destino):
        wb = Workbook()
        ws = wb.active
        ws.title = "ETA Info"
        ws.append(["Expected ETA", "Actual ETA"])
    else:
        wb = load_workbook(ruta_destino)
        ws = wb.active

    ws.append([expected, actual])
    wb.save(ruta_destino)

async def extraer_cosco():
    fecha = datetime.now().strftime("%Y-%m-%d")
    base = carpeta_dia()
    ruta_excel = os.path.join(base, "TRACKING-BL.xlsx")
    ruta_eta = os.path.join(base, "ETA.xlsx")
    ruta_expected_actual = os.path.join(base, "ETA_Info.xlsx")
    log_folder = os.path.join(base, "Log")
    os.makedirs(log_folder, exist_ok=True)
    carpeta_log = os.path.join(os.path.expanduser("~"), "Documents", "TRACKING-BL", "BL_Consultados")
    os.makedirs(carpeta_log, exist_ok=True)
    ruta_log = os.path.join(carpeta_log, "log_tracking.xlsx")

    registros_anteriores = cargar_registros_eta(ruta_eta)

    datos = obtener_datos_tracking()
    trackings = filtrar_codigos(datos)
    if not trackings:
        print("⚠️ No hay códigos válidos.")
        return

    encontrados = []
    no_encontrados = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(channel="chrome", headless=True, args=["--disable-blink-features=AutomationControlled", "--disable-infobars"])
        context = await browser.new_context(
            user_agent="Mozilla/5.0",
            viewport={"width": 1280, "height": 720},
            locale="en-US"
        )
        page = await context.new_page()

        total = len(trackings)
        for idx, (do, tracking) in enumerate(trackings, 1):
            print(f"\n🔄 Consultando DO {idx} de {total}: {do} - {tracking}")
            tipo = "CONTAINER" if tracking.startswith(("TII", "FF", "OO", "TL", "TR", "TX", "TG")) else "BOOKING"
            codigo = tracking[4:] if tracking.startswith("COSU") else tracking
            url = f"https://elines.coscoshipping.com/scct/public/ct/base?lang=en&trackingType={tipo}&number={codigo}"
            try:
                await page.goto(url, timeout=60000)
                await page.mouse.move(200, 200)
                await page.wait_for_timeout(3000)

                html = await page.content()
                if "abnormal" in html:
                    print(f"🚫 Acceso bloqueado para {tracking}")
                    no_encontrados.append([do, tracking, "No Encontrado"])
                    continue

                clicked = await page.evaluate("""() => {
                    const span = Array.from(document.querySelectorAll('span')).find(el => el.textContent.trim() === 'Print');
                    if (span) {
                        const clickable = span.closest('div[style*="cursor"]') || span;
                        clickable.click();
                        return true;
                    }
                    return false;
                }""")
                await page.wait_for_timeout(3000)

                texto_expected_actual = await page.evaluate("""() => {
                    const el = Array.from(document.querySelectorAll('td')).find(td => td.innerText.includes('Expected') && td.innerText.includes('Actual'));
                    return el ? el.innerText.trim() : null;
                }""")
                if texto_expected_actual:
                    guardar_expected_actual(texto_expected_actual, ruta_expected_actual)

                eta_fecha = await page.evaluate("""() => {
                    const tabla = document.querySelector('table[style="table-layout: auto;"]');
                    if (!tabla) return null;
                    const tds = tabla.querySelectorAll("td.ant-table-cell");
                    for (let i = tds.length - 1; i >= 0; i--) {
                        const texto = tds[i].innerText.trim();
                        if (texto && texto.length > 6) {
                            return texto;
                        }
                    }
                    return null;
                }""")

                if not eta_fecha or eta_fecha == "Aún no ha llegado a puerto":
                    print(f"⚠️ No Encontrado {tracking}")
                    no_encontrados.append([do, tracking, "ETA no disponible"])
                    continue

                eta_anterior = registros_anteriores.get(do)
                if eta_anterior:
                    if eta_anterior == eta_fecha:
                        estado_eta = "Sin Cambio"
                    else:
                        estado_eta = "Cambio"
                else:
                    estado_eta = "Nuevo"

                if estado_eta == "Sin Cambio":
                    print("🔁 ETA Sin cambios")
                    encontrados.append([do, tracking, "Sin Cambio"])
                    continue

                hoja_destino = "Cosco_Shipping"
                datos_extraidos = []

                if clicked:
                    basepdf = os.path.join(os.path.expanduser("~"), "Documents", "TRACKING-BL", "PDF")
                    fecha_hora = datetime.now().strftime("%Y%m%d_%H%M%S")
                    pdf_name = f"{do}-TRK_{tracking}_{fecha_hora}.pdf"
                    pdf_path = os.path.join(basepdf, pdf_name)

                    html = await page.content()
                    soup = BeautifulSoup(html, "html.parser")
                    tbody = soup.select_one("#rc-tabs-1-panel-FULL_CHAIN tbody")

                    if tbody:
                        rows = [tr for tr in tbody.find_all("tr") if tr.find_all("td")]
                        if len(rows) >= 2:
                            ultimos = rows[-2:]
                            for tr in ultimos:
                                celdas = [td.get_text(strip=True) for td in tr.find_all("td")]
                                if len(celdas) >= 6:
                                    datos_extraidos.append([do, tracking, celdas[0], celdas[5], celdas[1], celdas[2], celdas[3], celdas[4]])
                    else:
                        tabla_alt = soup.find("table", attrs={"style": "table-layout: auto;"})
                        if tabla_alt:
                            filas = tabla_alt.find_all("tr")
                            for tr in filas:
                                celdas = [td.get_text(strip=True) for td in tr.find_all("td")]
                                if len(celdas) >= 4:
                                    datos_extraidos.append([do, tracking, celdas[0], celdas[1], "", "", celdas[2], celdas[3]])
                            if tipo == "CONTAINER":
                                hoja_destino = "Cosco_contenedor"

                    if datos_extraidos:
                        await page.pdf(path=pdf_path, format="A4", print_background=True)
                        guardar_excel(datos_extraidos, hoja_destino, HEADERS, ruta_excel, estado_eta, eta_fecha)
                        guardar_fecha_cosco_eta(ruta_eta, do, tracking, eta_fecha, estado_eta)
                        print(f"📄 PDF generado - Estado: {estado_eta}")
                        encontrados.append([do, tracking, estado_eta])
                    else:
                        print(f"⚠️ No se extrajeron datos útiles.")
                        no_encontrados.append([do, tracking, "No Encontrado"])
                else:
                    print(f"❌ No se pudo hacer clic en Print para {tracking}")
                    no_encontrados.append([do, tracking, "No Encontrado"])

            except Exception as e:
                print(f"❌ Error procesando {tracking}: {e}")
                no_encontrados.append([do, tracking, "Error"])

        await browser.close()

    # 🔽 Guardar logs de ejecución actual
    datos_log = [(do, tr, estado) for do, tr, estado in encontrados + no_encontrados]
    log_sql(datos_log, ruta_archivo=ruta_log)
    from Conexion.registro_log import insertar_varios
    insertar_varios(datos_log, naviera="COSCO")

    # 🔄 Generar registro global cruzado
    datos_sql = obtener_datos_tracking()
    log_dict = {(do, tr): estado for do, tr, estado in datos_log}

    registro_global = []
    for do, tracking in datos_sql:
        estado = log_dict.get((do, tracking), "NO CONSULTADO")
        fecha = datetime.now().strftime("%Y-%m-%d")
        registro_global.append({
            "DO": do,
            "TRACKING": tracking,
            "ESTADO": estado,
            "FECHA": fecha
        })
        

    

    
    
    
    from openpyxl import Workbook, load_workbook

    carpeta_log = os.path.join(os.path.expanduser("~"), "Documents", "TRACKING-BL", "BL_Consultados")
    os.makedirs(carpeta_log, exist_ok=True)
    ruta_registro_global = os.path.join(carpeta_log, "registro_global.xlsx")

    if os.path.exists(ruta_registro_global):
        wb = load_workbook(ruta_registro_global)
        ws = wb.active

        # Crear índice de registros existentes (DO+TRACKING → fila)
        registros_existentes = {
            (str(ws.cell(row=i, column=1).value), str(ws.cell(row=i, column=2).value)): i
            for i in range(2, ws.max_row + 1)
        }

        for reg in datos_log:  # ✅ SOLO actualizamos los consultados en este script
            do, tr, estado = reg
            clave = (str(do), str(tr))
            if clave in registros_existentes:
                fila = registros_existentes[clave]
                ws.cell(row=fila, column=3, value=estado)  # Estado
                ws.cell(row=fila, column=4, value=datetime.now().strftime("%Y-%m-%d"))  # Fecha
            else:
                ws.append([do, tr, estado, datetime.now().strftime("%Y-%m-%d")])

    else:
        # Crear nuevo archivo desde cero
        wb = Workbook()
        ws = wb.active
        ws.title = "Registro_Global"
        ws.append(["DO", "TRACKING", "ESTADO", "FECHA"])
        for do, tr, estado in datos_log:  # ✅ Solo lo de este script
            ws.append([do, tr, estado, datetime.now().strftime("%Y-%m-%d")])

    wb.save(ruta_registro_global)
    print(f"📄 Registro global actualizado en {ruta_registro_global}")


    
    
    
    
    

    #mover_pdfs()
    print(f"\n✅ Cosco_Shipping finalizado. Total: {len(trackings)} | ✔️ Encontrados: {len(encontrados)} | ❌ No encontrados: {len(no_encontrados)}")

if __name__ == "__main__":
    import asyncio
    asyncio.run(extraer_cosco())
