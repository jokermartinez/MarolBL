import os
import re
import asyncio
from datetime import datetime
from openpyxl import Workbook, load_workbook
from openpyxl.utils.exceptions import InvalidFileException
from Conexion.SQL_Navieras import CHECK_TABLE, INSERT_INTO, obtener_datos_tracking
from Datos.guardar_log import log_sql
from Datos.mover_pdfs import mover_pdfs
from playwright.async_api import async_playwright

# ✅ FUNCION EXTRAÍDA PARA ACTUALIZAR REGISTRO GLOBAL
def actualizar_registro_global(datos_log, carpeta_log):
    from openpyxl import Workbook, load_workbook
    from datetime import datetime
        # Guardar log de ejecución actual
    carpeta_log = os.path.join(os.path.expanduser("~"), "Documents", "TRACKING-BL", "BL_Consultados")
    os.makedirs(carpeta_log, exist_ok=True)
    ruta_registro_global = os.path.join(carpeta_log, "registro_global.xlsx")
    fecha_actual = datetime.now().strftime("%Y-%m-%d")

    if os.path.exists(ruta_registro_global):
        wb = load_workbook(ruta_registro_global)
        ws = wb.active

        registros_existentes = {
            (str(ws.cell(row=i, column=1).value), str(ws.cell(row=i, column=2).value)): i
            for i in range(2, ws.max_row + 1)
        }

        for do, tr, estado, *_ in datos_log:
            clave = (str(do), str(tr))
            if clave in registros_existentes:
                fila = registros_existentes[clave]
                ws.cell(row=fila, column=3, value=estado)
                ws.cell(row=fila, column=4, value=fecha_actual)
            else:
                ws.append([do, tr, estado, fecha_actual])
    else:
        wb = Workbook()
        ws = wb.active
        ws.title = "Registro_Global"
        ws.append(["DO", "TRACKING", "ESTADO", "FECHA"])
        for do, tr, estado, *_ in datos_log:
            ws.append([do, tr, estado, fecha_actual])

    wb.save(ruta_registro_global)
    print(f"📄 Registro global actualizado en {ruta_registro_global}")


# --------------------------------------------------------------------
fecha = datetime.now().strftime("%Y%m%d %H%M%S")
fecha_fin = fecha.replace('-', '')
PREFIJOS_VALIDOS = ("BS", "TC", "GC", "UE", "ONE", "BK", "FF", "DR", "TR")


def procesar_tracking(codigo: str) -> str:
    if "ONEY" in codigo:
        return codigo.replace("ONEY", "ON")[-12:]
    return codigo


def obtener_trackings_filtrados():
    datos = obtener_datos_tracking()
    resultados = []
    for do, doc_transp in datos:
        if "ONEY" in doc_transp:
            tracking = doc_transp[doc_transp.index("ONEY"):]
            procesado = procesar_tracking(tracking)
            resultados.append((do, tracking, procesado))
        elif doc_transp.startswith(PREFIJOS_VALIDOS):
            resultados.append((do, doc_transp, doc_transp))
    print(f"✅ Trackings válidos: {len(resultados)}")
    return resultados


def obtener_eta_actual(ruta_archivo):
    datos = {}
    if not os.path.exists(ruta_archivo):
        return datos
    wb = load_workbook(ruta_archivo)
    if "One_ETA" not in wb.sheetnames:
        return datos
    ws = wb["One_ETA"]
    for row in ws.iter_rows(min_row=2, values_only=True):
        if row[0] and row[6]:
            datos[row[0]] = row[6]
    return datos


def guardar_datos_eta(ruta_archivo, nuevos_datos):
    if os.path.exists(ruta_archivo):
        wb = load_workbook(ruta_archivo)
    else:
        wb = Workbook()

    if "Sheet" in wb.sheetnames and not wb["Sheet"]["A1"].value:
        wb.remove(wb["Sheet"])

    if "One_ETA" in wb.sheetnames:
        ws = wb["One_ETA"]
    else:
        ws = wb.create_sheet("One_ETA")
        encabezado = ["DO", "TRACKING", "Vessel", "Puerto de carga", "Fecha de salida", "MOTONAVE", "ETA FECHA LLEGADA", "ESTADO"]
        ws.append(encabezado)

    existentes = {row[0]: row[6] for row in ws.iter_rows(min_row=2, values_only=True) if row[0] and row[6]}

    for fila in nuevos_datos:
        do, nueva_eta = fila[0], fila[6]
        if do in existentes and existentes[do] == nueva_eta:
            print(f"🔁 {do} ETA Sin cambios.")
            continue
        fila.append("cambio" if do in existentes else "")
        ws.append(fila)

    wb.save(ruta_archivo)


def guardar_datos_tracking(ruta_archivo, datos):
    if os.path.exists(ruta_archivo):
        wb = load_workbook(ruta_archivo)
    else:
        wb = Workbook()

    if "ONE_LINE" in wb.sheetnames:
        wb.remove(wb["ONE_LINE"])
    ws = wb.create_sheet("ONE_LINE")

    encabezado = ["DO", "Tracking", "Dato1", "Dato2", "Dato3", "Dato4", "Dato5"]
    ws.append(encabezado)

    for fila in datos:
        ws.append(fila)

    wb.save(ruta_archivo)
    print(f"📊 TRACKING-BL.xlsx actualizado")


def guardar_log_excel(log_data, carpeta_log):
    ruta_log = os.path.join(carpeta_log, "log_tracking.xlsx")
    if os.path.exists(ruta_log):
        try:
            wb = load_workbook(ruta_log)
        except InvalidFileException:
            wb = Workbook()
    else:
        wb = Workbook()

    if "One_Tracking" in wb.sheetnames:
        wb.remove(wb["One_Tracking"])
    ws = wb.create_sheet("One_Tracking")
    ws.append(["DO", "Tracking", "Estado", "PDF / ETA"])

    for fila in log_data:
        ws.append(fila)

    wb.save(ruta_log)
    print(f"📝 Log guardado")


async def cerrar_alerta_si_existe(page):
    try:
        ok_button = page.locator('button[data-cy="alert-emergency-system-btn"]')
        if await ok_button.is_visible():
            print("⚠️ Alerta detectada. Cerrando...")
            await ok_button.click()
            await page.wait_for_timeout(1000)
    except Exception as e:
        print(f"❌ Error al cerrar alerta: {e}")


async def generar_pdf_y_datos(page, do, tracking, procesado, carpeta, fecha, log_data, eta_existente, datos_tracking):
    try:
        await page.goto("https://ecomm.one-line.com/one-ecom", timeout=60000)
        await cerrar_alerta_si_existe(page)

        await page.locator("#quick-action_tracking-box").click()
        await page.wait_for_timeout(1000)
        await cerrar_alerta_si_existe(page)

        await page.fill("textarea[name='inputValue']", procesado)
        await cerrar_alerta_si_existe(page)

        await page.click("#__next > main > div.CommonLayout_main-left-menu__ah7M3.CommonLayout_left-menu___bHEf > div.CommonLayout_one-container__dL1bw > div.HomePage_homepage-container__BZVRe > div.HomePage_quickActionContainer__cCing > div.QuickAction_container__NaR_y > div.Tracking_isActive__G4ETe.Tracking_root__W2mMi > div > form > div.TrackInputAreaContent_group-button__OQujW > button.ScheduleButton_base__Mw_yk.ScheduleButton_colorPrimary__O4IU8.ScheduleButton_variantFilled__7dlkI.ScheduleButton_sizeMd__hd99r.TrackInputAreaContent_track-button__xPD4t")
        await page.wait_for_timeout(5000)
        await cerrar_alerta_si_existe(page)

        if await page.locator(".TextArea_errorMessage__2MKpw").is_visible():
            print(f"⚠️ Tracking inválido: {tracking}")
            log_data.append([do, tracking, "No Encontrado", ""])
            return

        await cerrar_alerta_si_existe(page)

        frame = page.frame(name="IframeCurrentEcom")
        if not frame:
            log_data.append([do, tracking, "No Encontrado", ""])
            return

        await frame.wait_for_selector("#main-grid", timeout=10000)

        tabla = frame.locator("#main-grid")
        filas = await tabla.locator("tr").all()
        for fila in filas[1:]:
            celdas = await fila.locator("td").all()
            valores = [await celda.inner_text() for celda in celdas]
            if valores:
                datos_tracking.append([do, tracking] + [v.strip() for v in valores[:5]])

        celda = frame.locator("#\\31  > td:nth-child(4)")
        if await celda.count() == 0:
            log_data.append([do, tracking, "No Encontrado", ""])
            return

        await celda.first.click()
        await frame.wait_for_selector("table#sailing", timeout=10000)

        fila = frame.locator("table#sailing tbody tr")
        celdas = await fila.locator("td").all()
        if len(celdas) < 5:
            log_data.append([do, tracking, "No Encontrado", ""])
            return

        vessel = await celdas[0].inner_text()
        puerto_carga = await celdas[1].inner_text()
        fecha_salida = await celdas[2].inner_text()
        motonave = await celdas[3].inner_text()
        eta = await celdas[4].inner_text()

        match = re.search(r"\d{4}-\d{2}-\d{2}", eta.strip())
        nueva_eta = match.group(0).replace("-", "/") if match else ""

        fila_eta = [
            do, tracking, vessel.strip(), puerto_carga.strip(),
            fecha_salida.strip(), motonave.strip(), nueva_eta
        ]

        ruta_eta = os.path.join(carpeta, "ETA.xlsx")
        guardar_datos_eta(ruta_eta, [fila_eta])

        existe, eta_db = CHECK_TABLE(do, return_eta=True)
        if existe and eta_db == nueva_eta:
            log_data.append([do, tracking, "Encontrado", "Sin cambios"])
            print(f"📌 PDF omitido para {do}: ETA sin cambios.")
            return
        else:
            estado = "actualizado" if existe else "nuevo"
            fecha_pdf = datetime.now().strftime("%Y-%m-%d %H-%M-%S")
            fecha_consulta = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            INSERT_INTO(do, tracking, nueva_eta, estado, "ONE", fecha_consulta)
            log_sql([(do, tracking, estado)], os.path.join(carpeta, "log_tracking.xlsx"))
            print(f"✅ ETA {estado} en DB y log: {do} - {nueva_eta}")

        base_dir1 = os.path.expanduser("~")
        carpetapdf = os.path.join(base_dir1, "Documents", "TRACKING-BL", "PDF")
        pdf_nombre = f"{do}-TRK_{tracking}_{fecha_pdf.replace('-', '')}.pdf"
        pdf_path = os.path.join(carpetapdf, pdf_nombre)
        await page.pdf(
            path=pdf_path,
            format="A4",
            print_background=True,
            scale=0.6,
            margin={"top": "0.5in", "bottom": "0.5in", "left": "0.5in", "right": "0.5in"}
        )
        print(f"📄 PDF generado: {pdf_nombre}")
        log_data.append([do, tracking, "Encontrado", "PDF actualizado"])

    except Exception as e:
        print(f"❌ Error en {do}: {e}")
        log_data.append([do, tracking, "Error", str(e)])


async def ejecutar_one_line_async():
    trackings = obtener_trackings_filtrados()
    if not trackings:
        print("⚠️ No hay trackings válidos.")
        return

    fecha_actual = datetime.now().strftime("%Y-%m-%d")
    carpeta = os.path.join(os.path.expanduser("~"), "Documents", "TRACKING-BL", fecha_actual)
    carpeta_log = os.path.join(carpeta, "Log")
    os.makedirs(carpeta, exist_ok=True)
    os.makedirs(carpeta_log, exist_ok=True)

    ruta_tracking = os.path.join(carpeta, "TRACKING-BL.xlsx")
    ruta_eta = os.path.join(carpeta, "ETA.xlsx")
    eta_existente = obtener_eta_actual(ruta_eta)

    log_data = []
    datos_tracking = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(channel="chrome", headless=False)
        page = await browser.new_page()

        total = len(trackings)
        for i, (do, tracking, procesado) in enumerate(trackings, 1):
            print(f"\n➡️ Procesando DO {i} de {total} → {do}")
            await generar_pdf_y_datos(
                page, do, tracking, procesado, carpeta,
                fecha_actual, log_data, eta_existente, datos_tracking
            )

        await browser.close()

    # guardar_datos_tracking(ruta_tracking, datos_tracking)
    # guardar_log_excel(log_data, carpeta_log)
    # actualizar_registro_global(log_data, carpeta_log)  # ✅ INTEGRACIÓN AQUÍ
    
    from Conexion.registro_log import insertar_varios
    insertar_varios(log_data, naviera="Ecomm")

  
    print("\n✅ Proceso completo.")


if __name__ == "__main__":
    asyncio.run(ejecutar_one_line_async())
 