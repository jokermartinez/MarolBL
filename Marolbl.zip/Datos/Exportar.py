
import os
import re
import asyncio
from datetime import datetime
from openpyxl import Workbook, load_workbook
from playwright.async_api import async_playwright
#from Class.conexion_sql_DO import obtener_datos_tracking
import subprocess
import os
import time
import subprocess
from datetime import datetime
import re
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
import webview
import json
import shutil
from bs4 import BeautifulSoup





from datetime import datetime
from Conexion.SQL_Navieras import obtener_datos_tracking, guardar_log_resultado2

def generar_log_completo2():
    """Genera un log de todos los datos obtenidos desde SQL (consultados o no)."""
    try:
        todos_datos = obtener_datos_tracking()  # [(do, tracking), ...]
        resultados = []

        for do, tracking in todos_datos:
            resultados.append({
                "DO": do,
                "TRACKING": tracking,
                "ESTADO": "PENDIENTE",   # Estado inicial antes de procesar
                "FECHA": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })

        # Guardar log específico de HAPPAG
        guardar_log_resultado2("HAPPAG", resultados)
        print(f"📝 Log inicial generado con {len(resultados)} registros.")

    except Exception as e:
        print(f"❌ Error al generar log completo: {e}")















fecha = datetime.now().strftime("%Y-%m-%d")
fecha_hora = datetime.now().strftime("%Y%m%d %H%M%S")
fecha_pdf = fecha_hora.replace('-', '')
fecha_fin = fecha.replace('-', '')


# ================================
# 📂 EXPORTAR DATOS
# ================================


async def guardar_pdf_Msc(page, carpeta, do, tracking):
    carpeta_pdf = os.path.join(os.path.expanduser("~"), "Documents", "TRACKING-BL", "PDF")
    os.makedirs(carpeta_pdf, exist_ok=True)
    nombre_pdf = f"{do}-TRK_{tracking}_{fecha_pdf}.pdf"
    ruta_pdf = os.path.join(carpeta_pdf, nombre_pdf)
    await page.pdf(path=ruta_pdf, format="A4", print_background=False)
    print(f"📄 PDF guardado: {tracking}")
    
    
    
def Msc_excel(carpeta, do, tracking, bloques):
    ruta_excel = os.path.join(carpeta, "TRACKING-BL.xlsx")
    wb = load_workbook(ruta_excel) if os.path.exists(ruta_excel) else Workbook()
    ws = wb["Msc_Tracking"] if "Msc_Tracking" in wb.sheetnames else wb.create_sheet("Msc_Tracking")
    if ws.max_row == 1 and not ws.cell(1, 1).value:
        ws.append(["DO", "Tracking", "Fecha", "Ubicación", "Descripción", "C/V/Barco/Viaje", "Puerto"])
    for bloque in bloques:
        ws.append([do, tracking] + bloque)
    wb.save(ruta_excel)
    print(f"📊 Datos guardados: {tracking}")

    
    
def Cma_folder():
    carpeta = os.path.join(os.path.expanduser("~"), "Documents", "TRACKING-BL", "PDF")
    os.makedirs(carpeta, exist_ok=True)
    return carpeta   
    
def export_pdf_Cma(window, tracking, do):
    try:
        js_click = """
        (function() {
            let boton = document.querySelector('a[href*="export-pdf"]');
            if (boton) {
                boton.click();
                return true;
            }
            return false;
        })()
        """
        success = window.evaluate_js(js_click)
        if not success:
            print(f"⚠ No se encontró botón PDF para {tracking}")
            return False

        print("⏳ Esperando descarga del PDF...")
        downloads = os.path.join(os.path.expanduser('~'), "Downloads")
        archivo_pdf = None
        for _ in range(20):
            archivos = [f for f in os.listdir(downloads) if f.endswith(".pdf")]
            archivos.sort(key=lambda x: os.path.getctime(os.path.join(downloads, x)), reverse=True)
            if archivos:
                archivo_pdf = archivos[0]
                break
            time.sleep(1)

        if archivo_pdf:
            origen = os.path.join(downloads, archivo_pdf)
            fecha_pdf = datetime.now().strftime("%Y%m%d %H%M%S")
            destino_dir = Cma_folder()
            destino = os.path.join(destino_dir, f"{do}-TRK_{tracking}_{fecha_pdf}.pdf")
            shutil.move(origen, destino)
            print(f"✅ PDF guardado: {destino}")
            return True
        else:
            print(f"⚠ No se encontró PDF descargado para {tracking}")
            return False
    except Exception as e:
        print(f"❌ Error moviendo PDF: {e}")
        return False

    

def export_pdf_Zim2(window, do, tracking):
    fecha_pdf = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_folder = os.path.join(
        os.path.expanduser("~"), "Documents", "TRACKING-BL", "PDF"
    )
    os.makedirs(output_folder, exist_ok=True)

    output_file = os.path.join(
        output_folder, f"{do}-TRK_{tracking}_{fecha_pdf}.pdf"
    )

    exe_path = r"C:\Users\ADMINISTRATOR\Documents\NAVIERAS_ENTREGA\Datos\ZimExporter\ZimExporter\ZimExporter\bin\Debug\ZimExporter.exe"

    if not os.path.exists(exe_path):
        print("❌ No se encuentra ZimExporter.exe.")
        print(f"Ruta esperada: {exe_path}")
        return

    try:
        subprocess.run([exe_path, tracking, output_file], check=True)
        print(f"✅ PDF generado: {output_file}")
    except subprocess.CalledProcessError as e:
        print(f"❌ Error ejecutando el exportador: {e}")





    
def export_pdf_Zim(window, do, tracking):
    base_dir = os.path.expanduser("~")
    fecha_pdf = datetime.now().strftime("%Y-%m-%d %H-%M-%S")
    output_folder = os.path.join(base_dir, "Documents", "TRACKING-BL", "PDF")
    os.makedirs(output_folder, exist_ok=True)
    output_file = os.path.join(output_folder, f"{do}-TRK_{tracking}_{fecha_pdf.replace('-', '')}.pdf")
    # Ruta_pdf_exe = os.path.dirname(os.path.abspath(__file__))
    # Ruta_pdf = r"\ZimExporter\ZimExporter\bin\Debug\ZimExporter.exe"
    
    
    
        # Ruta base donde se ejecuta el script actual
    base_path = os.path.dirname(os.path.abspath(__file__))

    # Ruta relativa al ejecutable
    relative_exe_path = os.path.join("ZimExporter", "ZimExporter", "bin", "Debug", "ZimExporter.exe")
    
    # Ruta completa al .exe
    exe_path = os.path.join(base_path, relative_exe_path)

    if not os.path.exists(exe_path):
        print("❌ No se encuentra ZimExporter.exe.")
        print(f"Ruta esperada: {exe_path}")
        return

    try:
        subprocess.run([exe_path, tracking, output_file], check=True)
        print(f"✅ PDF generado: {output_file}")
    except subprocess.CalledProcessError as e:
        print(f"❌ Error ejecutando el exportador: {e}")

# def Ruta_Carpeta():
#     carpeta = os.path.join(os.path.expanduser("~"), "Documents", "TRACKING-BL", fecha)
#     os.makedirs(carpeta, exist_ok=True)
#     return carpeta




import os
from openpyxl import Workbook, load_workbook

def save_data_to_excel1(carpeta, tracking, data):
    """Guarda los datos generales del tracking en hoja 'EVERGREEN_DATA'."""
    ruta_excel = os.path.join(carpeta, "TRACKING-BL.xlsx")

    if os.path.exists(ruta_excel):
        wb = load_workbook(ruta_excel)
    else:
        wb = Workbook()
        wb.remove(wb.active)

    if "EVERGREEN_DATA" in wb.sheetnames:
        ws = wb["EVERGREEN_DATA"]
    else:
        ws = wb.create_sheet("EVERGREEN_DATA")
        ws.append(["Tracking", "Evento", "Puerto", "Ubicación", "Fecha Estimada"])

    for fila in data:
        ws.append([tracking] + fila)

    wb.save(ruta_excel)

def save_container_table(carpeta, detalle_bl, tracking, rows):
    """Guarda la tabla de contenedores asociada a un tracking."""
    ruta_excel = os.path.join(carpeta, "TRACKING-BL.xlsx")

    if os.path.exists(ruta_excel):
        wb = load_workbook(ruta_excel)
    else:
        wb = Workbook()
        wb.remove(wb.active)

    sheet_name = f"{tracking[:10]}_CTN"
    if sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
    else:
        ws = wb.create_sheet(sheet_name)
        ws.append(["Contenedor", "Tamaño", "Tipo", "Estado", "Peso", "Fecha", "Ubicación", "Evento", "Destino"])

    for fila in rows:
        ws.append(fila)

    wb.save(ruta_excel)
    
    
def excel_evergreen(carpeta, tracking, data):
    """Guarda los datos generales del tracking en hoja 'EVERGREEN_DATA'."""
    ruta_excel = os.path.join(carpeta, "TRACKING-BL.xlsx")

    if os.path.exists(ruta_excel):
        wb = load_workbook(ruta_excel)
    else:
        wb = Workbook()
        wb.remove(wb.active)

    if "EVERGREEN_DATA" in wb.sheetnames:
        ws = wb["EVERGREEN_DATA"]
    else:
        ws = wb.create_sheet("EVERGREEN_DATA")
        ws.append(["Tracking", "Evento", "Puerto", "Ubicación", "Fecha Estimada"])

    for fila in data:
        ws.append([tracking] + fila)

    wb.save(ruta_excel)


def log_sql(datos, ruta_archivo="log_tracking.xlsx"):
    """
    Guarda los datos (DO, Tracking, Estado) en la hoja global 'TODOS_NL' de un archivo Excel.

    datos: lista de tuplas (DO, Tracking, Estado)
    ruta_archivo: ruta completa del archivo Excel
    """
    # 1. Cargar o crear el archivo
    if os.path.exists(ruta_archivo):
        wb = load_workbook(ruta_archivo)
    else:
        wb = Workbook()
        wb.remove(wb.active)  # Eliminar hoja por defecto

    # 2. Crear o acceder a la hoja global
    if "TODOS_NL" not in wb.sheetnames:
        hoja = wb.create_sheet("TODOS_NL")
        hoja.append(["DO", "Tracking", "Estado", "Fecha Consulta"])  # encabezados
    else:
        hoja = wb["TODOS_NL"]

    # 3. Leer registros existentes para evitar duplicados
    registros_existentes = {(fila[0].value, fila[1].value): fila for fila in hoja.iter_rows(min_row=2)}

    fecha_actual = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # 4. Insertar o actualizar registros
    for do, tracking, estado in datos:
        key = (do, tracking)
        if key in registros_existentes:
            fila = registros_existentes[key]
            fila[2].value = estado
            fila[3].value = fecha_actual
        else:
            hoja.append([do, tracking, estado, fecha_actual])

    # 5. Guardar archivo
    wb.save(ruta_archivo)