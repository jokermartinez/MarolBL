# archivo: guardar_log.py
import os
from openpyxl import Workbook, load_workbook
from datetime import datetime

def log_sql(datos, ruta_archivo="log_tracking.xlsx"):
    """
    Guarda los datos (DO, Tracking, Estado) en la hoja global 'TODOS_NL' de un archivo Excel.

    datos: lista de tuplas (DO, Tracking, Estado)
    ruta_archivo: ruta completa del archivo Excel
    """
    # 1. Cargar o crear el archivo
    if os.path.exists(ruta_archivo):
        wb = load_workbook(ruta_archivo)
    else:
        wb = Workbook()
        wb.remove(wb.active)  # Eliminar hoja por defecto

    # 2. Crear o acceder a la hoja global
    if "TODOS_NL" not in wb.sheetnames:
        hoja = wb.create_sheet("TODOS_NL")
        hoja.append(["DO", "Tracking", "Estado", "Fecha Consulta"])  # encabezados
    else:
        hoja = wb["TODOS_NL"]

    # 3. Leer registros existentes para evitar duplicados
    registros_existentes = {(fila[0].value, fila[1].value): fila for fila in hoja.iter_rows(min_row=2)}

    fecha_actual = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # 4. Insertar o actualizar registros
    for do, tracking, estado in datos:
        key = (do, tracking)
        if key in registros_existentes:
            fila = registros_existentes[key]
            fila[2].value = estado
            fila[3].value = fecha_actual
        else:
            hoja.append([do, tracking, estado, fecha_actual])

    # 5. Guardar archivo
    wb.save(ruta_archivo)



def guardar_log(datos, nombre_hoja, ruta_archivo="log_trackings.xlsx"):
    """
    datos: lista de tuplas (DO, Tracking, Estado)
    nombre_hoja: hoja específica por naviera (ej. 'MSC_TRACKING')
    ruta_archivo: ruta completa del archivo de log independiente
    """
    carpeta = os.path.dirname(ruta_archivo)
    if carpeta:
        os.makedirs(carpeta, exist_ok=True)

    if os.path.exists(ruta_archivo):
        wb = load_workbook(ruta_archivo)
    else:
        wb = Workbook()
        wb.remove(wb.active)

    # --- Hoja individual por naviera ---
    if nombre_hoja not in wb.sheetnames:
        hoja = wb.create_sheet(nombre_hoja)
        hoja.append(["DO", "Tracking", "Estado", "Fecha Consulta"])
    else:
        hoja = wb[nombre_hoja]

    registros_existentes = {(fila[0].value, fila[1].value): fila for fila in hoja.iter_rows(min_row=2)}

    fecha_actual = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    for do, tracking, estado in datos:
        key = (do, tracking)
        if key in registros_existentes:
            fila = registros_existentes[key]
            fila[2].value = estado
            fila[3].value = fecha_actual
        else:
            hoja.append([do, tracking, estado, fecha_actual])

    # --- Hoja global TODOS_NL ---
    if "TODOS_NL" not in wb.sheetnames:
        global_ws = wb.create_sheet("TODOS_NL")
        global_ws.append(["DO", "Tracking", "Estado", "Naviera", "Fecha Consulta"])
    else:
        global_ws = wb["TODOS_NL"]

    for do, tracking, estado in datos:
        global_ws.append([do, tracking, estado, nombre_hoja, fecha_actual])

    wb.save(ruta_archivo)


