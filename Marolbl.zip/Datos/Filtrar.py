
import os
import re
import asyncio
from datetime import datetime
from openpyxl import Workbook, load_workbook
from playwright.async_api import async_playwright
from Conexion.SQL_Navieras import CHECK_TABLE, INSERT_INTO, obtener_datos_tracking, guardar_log_resultado




# ================================
# 📊 FILTRO ZIM
# ================================

def trackings_Zim(datos_sql):
    try:
        datos_sql = obtener_datos_tracking()
        filtrados = [item for item in datos_sql if item[1].startswith(("Z", "ZM", "ZIM"))]
        print(f"🔍 Trackings que inician con 'Z': {len(filtrados)}")
        return filtrados
    except Exception as e:
        print(f"❌ Error obteniendo datos SQL: {e}")
        return []
    
    
    
def trackings_Zim2():
    try:
        datos_sql = obtener_datos_tracking()
        filtrados = [item for item in datos_sql if item[1].startswith(("Z", "ZM", "ZIM"))]
        print(f"🔍 Trackings que inician con 'Z': {len(filtrados)}")
        return filtrados
    except Exception as e:
        print(f"❌ Error obteniendo datos SQL: {e}")
        return []
    
# ================================
# 📊 FILTRO COSCO
# ================================
    
def Filtro_Cosco(Fecha):
    # Extraer la parte después de "Expected:" (con ":" normal o con "：" unicode)
    if "Expected：" in Fecha:
        fecha_completa = Fecha.split("Expected：")[1].split("\n")[0].strip()
    else:
        fecha_completa = Fecha.split("Expected:")[1].split("\n")[0].strip()
    
    # Devolver solo la parte de la fecha (YYYY-MM-DD)
    fecha_sin_hora = fecha_completa.split()[0]
    fecha_formateada = fecha_sin_hora.replace('-', '/')
    return fecha_formateada


# ================================
# 📊 FILTRO MARFREET
# ================================
def Filtro_Marfreet(Fecha):
    fecha = Fecha.split("Expected：")[1].split("\n")[0].strip()
    fecha_sin_hora = fecha.split()[0]  # Esto tomará solo la parte de la fecha antes de la hora
    return fecha_sin_hora